<?php require('partials/header.php'); ?>
<?php require('partials/nav.php'); ?>

<div class="container mt-3">
  <h1>Halaman About</h1>
</div>

<?php require('partials/footer.php'); ?>