<footer id="footer">
    
    <div class="credite text-center">
   <a> Created By <span>Febi Alia Rahman</span> | 223040059</a>
    </div>
    <div class="copyright text-center">
      &copy; Copyright <strong><span>Culinary</span></strong>. Tubes
  </div>
</footer>
  



  </div>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>
</html>