<!DOCTYPE html>
<html>

<head>
    <title>berita</title>
    <link rel="stylesheet" href="berita1.css" />
</head>

<body>
    <div class="container">
        <div class="header">
            <h1 class="judul">MyWebsite</h1>
            <ul>
                <li><a href="#">home</a></li>
                <li><a href="#">about</a></li>
                <li><a href="#">products</a></li>
                <li><a href="#">services</a></li>
                <li><a href="#">contact</a></li>
            </ul>
        </div>
        <div class="hero"></div>
        <div class="content">
            <h2>Judul Artikel</h2>
            <p class="penulis">
                ditulis oleh <a href="#">aureliare</a>. Pada 9 November 2022.
            </p>

            <p>
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime ad,
                voluptas est voluptate esse tempore tenetur dolorum adipisci debitis
                dolorem amet dolore cum expedita quas? Provident nesciunt voluptatibus
                voluptas quae.
            </p>

            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias
                culpa numquam odit tempore dolor modi ex? Sint nesciunt ad atque id,
                debitis dicta dolorem neque, corrupti inventore provident culpa
                dolores tempore beatae earum minus tempora optio iure veritatis
                aliquid? Natus, autem delectus architecto vero reprehenderit a
                deleniti in assumenda. Rerum consequuntur soluta corporis? Similique,
                laudantium unde officiis sint voluptates minus vero pariatur nam
                reiciendis reprehenderit quidem in temporibus architecto, fugiat
                deleniti beatae, nobis porro explicabo vel fugit ipsa distinctio!
                Asperiores ex nemo dolorem, similique consequatur itaque in, incidunt
                quos et autem ut tempora recusandae quas ab impedit voluptatum labore.
                Ex?
            </p>

            <p>
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nostrum
                deleniti, quos atque suscipit laudantium error debitis nisi recusandae
                necessitatibus optio, repudiandae excepturi dicta neque provident ab
                explicabo commodi nesciunt iste. Eveniet illo molestiae nobis maiores
                atque, laborum, magnam quo sapiente ipsam eius quia culpa unde optio
                consequuntur rem velit! Ab aliquid deleniti, tempore numquam sequi
                illum velit neque error magni placeat eveniet omnis exercitationem quo
                commodi laboriosam! Quaerat impedit, repellendus maxime dolores
                molestiae repellat dignissimos laudantium, tempore odio totam vel!
            </p>
        </div>
        <div class="footer">
            <div class="copy">Copyright 2016. aureliare</div>
        </div>
    </div>
</body>

</html>